#include <iostream>
#include <string>
#include <sstream>

using namespace std;

int main(){
    int dado = rand() % 100;
    cout << dado;
    return 0;
}