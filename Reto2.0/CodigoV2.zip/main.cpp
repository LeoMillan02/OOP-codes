#include <iostream>
#include <string>
#include <sstream>

using namespace std;

#include "Protagonista.h"
#include "Enemigo.h"
#include "juego.h"

int main(){

    Juego game;

    game.load();
    
    return 0;
}